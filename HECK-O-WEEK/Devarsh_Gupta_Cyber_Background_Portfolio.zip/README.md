# Devarsh Gupta — Portfolio

## How to run
1. Open this folder in VS Code.
2. Open `index.html`.
3. Use Live Server if installed, or simply open `index.html` in a browser.

## Topics demonstrated
- HTML5 semantic elements: header, nav, main, section, article, footer
- Accessible labels, alt-equivalent text handling, button states, ARIA attributes, focus states
- HTML forms with validation
- CSS variables
- Flexbox
- CSS Grid
- Responsive design with media queries
- Basic JavaScript for the mobile menu and demo form interaction

## Files
- `index.html`
- `style.css`

- `assets/cyber-network-background.png` — supplied full-page cyber network background
