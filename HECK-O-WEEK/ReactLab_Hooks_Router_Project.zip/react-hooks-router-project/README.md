# ReactLab — Hooks & Router Practice Project

A ready-to-run React + Vite project covering:

- `useRef`
- `useMemo`
- `useCallback`
- `useContext`
- Custom hooks (`useLocalStorage`, `useDocumentTitle`)
- React Router routes
- Nested routes with `<Outlet />`
- URL params with `useParams()`
- Navigation with `<Link />` and `useNavigate()`

## Run

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Project map

```text
src/
├── components/       reusable UI
├── context/          useContext + Provider
├── hooks/            custom hooks
├── layouts/          main + nested dashboard layout
├── pages/            route screens
├── data.js           demo course data
├── App.jsx           route tree
├── main.jsx          app entry
└── styles.css        full responsive styling
```

## Routes to test

- `/`
- `/hooks`
- `/router`
- `/dashboard`
- `/dashboard/profile`
- `/dashboard/courses`
- `/dashboard/courses/react`
- `/dashboard/courses/python`
- `/dashboard/courses/cybersecurity`

## What each concept does in this project

### Hooks Lab
- `useRef`: focuses an input and tracks render count without storing it in state.
- `useMemo`: filters students and calculates totals only when dependencies change.
- `useCallback`: passes a stable handler to a memoized child button.
- `useContext`: shares dark/light theme across the app.
- Custom hook: `useLocalStorage` persists values across refreshes.

### Router Lab
- Routes: `/hooks`, `/router`, `/dashboard` etc.
- Nested routes: dashboard children render via `<Outlet />`.
- Params: `/dashboard/courses/:courseId` + `useParams()`.
- Navigation: `Link`, `NavLink`, and `useNavigate()`.
