import { memo, useCallback, useMemo, useRef, useState } from 'react'
import { useTheme } from '../context/ThemeContext'
import { useLocalStorage } from '../hooks/useLocalStorage'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import Section from '../components/Section'

const students = [
  { id: 1, name: 'Aarav', course: 'React', score: 94 },
  { id: 2, name: 'Diya', course: 'JavaScript', score: 88 },
  { id: 3, name: 'Kabir', course: 'React', score: 91 },
  { id: 4, name: 'Anaya', course: 'Node.js', score: 84 },
  { id: 5, name: 'Vihaan', course: 'React', score: 97 },
]

const ChildButton = memo(function ChildButton({ onAction, count }) {
  return <button className="btn secondary" onClick={onAction}>Child clicked {count} times</button>
})

export default function HooksLab() {
  useDocumentTitle('Hooks Lab')
  const { theme } = useTheme()
  const inputRef = useRef(null)
  const renderCount = useRef(0)
  renderCount.current += 1
  const [count, setCount] = useState(0)
  const [query, setQuery] = useState('')
  const [savedName, setSavedName] = useLocalStorage('reactlab-name', 'Devarsh')

  const filteredStudents = useMemo(() => {
    const q = query.trim().toLowerCase()
    return q ? students.filter((s) => `${s.name} ${s.course}`.toLowerCase().includes(q)) : students
  }, [query])

  const expensiveTotal = useMemo(() => {
    return filteredStudents.reduce((sum, student) => sum + student.score, 0)
  }, [filteredStudents])

  const handleChildAction = useCallback(() => setCount((c) => c + 1), [])

  return (
    <div>
      <Section eyebrow="HOOK 01" title="useRef — DOM reference + persistent value">
        <div className="two-col">
          <div className="demo-card glass">
            <h3>Focus an input</h3><p>Click the button to call <code>inputRef.current.focus()</code>.</p>
            <div className="inline"><input ref={inputRef} placeholder="Type something…" /><button className="btn primary" onClick={() => inputRef.current?.focus()}>Focus input</button></div>
          </div>
          <div className="demo-card glass"><h3>No re-render storage</h3><p>Every render increments the ref, but changing the ref itself does not cause a render.</p><div className="metric">Render count: <b>{renderCount.current}</b></div><button className="btn secondary" onClick={() => setCount((c) => c + 1)}>Trigger re-render</button></div>
        </div>
      </Section>

      <Section eyebrow="HOOK 02" title="useMemo — memoized calculation">
        <div className="demo-card glass">
          <div className="inline spread"><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search students or courses…"/><span className="badge">Theme: {theme}</span></div>
          <p className="muted">Filtered score total (computed with useMemo): <b>{expensiveTotal}</b></p>
          <div className="student-list">{filteredStudents.map(s => <div className="student-row" key={s.id}><strong>{s.name}</strong><span>{s.course}</span><b>{s.score}</b></div>)}</div>
        </div>
      </Section>

      <Section eyebrow="HOOK 03" title="useCallback — stable function reference">
        <div className="demo-card glass"><p>The callback is memoized, so the child receives a stable function reference while its dependencies remain unchanged.</p><ChildButton onAction={handleChildAction} count={count}/></div>
      </Section>

      <Section eyebrow="HOOK 04" title="useContext — shared theme state">
        <div className="demo-card glass"><p>This card reads the global theme directly through <code>useTheme()</code>, without prop drilling.</p><div className="metric">Current theme: <b>{theme}</b></div></div>
      </Section>

      <Section eyebrow="CUSTOM HOOK" title="useLocalStorage — reusable logic">
        <div className="demo-card glass"><p>This custom hook combines state + localStorage persistence.</p><div className="inline"><input value={savedName} onChange={(e) => setSavedName(e.target.value)} placeholder="Your name"/><span className="badge">Saved automatically</span></div><p className="muted">Refresh the page — your name remains because the hook stores it locally.</p></div>
      </Section>
    </div>
  )
}
