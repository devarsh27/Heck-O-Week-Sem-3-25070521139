import { Link } from 'react-router-dom'
import { useDocumentTitle } from '../hooks/useDocumentTitle'

const concepts = [
  ['useRef', 'Hold DOM refs or mutable values without re-rendering.'],
  ['useMemo', 'Cache a calculated value when its inputs stay the same.'],
  ['useCallback', 'Cache a function reference for stable child props.'],
  ['useContext', 'Read shared values without passing props through every level.'],
  ['Custom Hooks', 'Package reusable stateful logic into a function beginning with use.'],
  ['Router', 'Move between pages, nested screens and dynamic URL params.'],
]

export default function Home() {
  useDocumentTitle('Home')
  return (
    <div>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow">HACK-O-WEEK • REACT PRACTICE PROJECT</div>
          <h1>Learn React by <span>using it.</span></h1>
          <p>A full-stack-looking frontend lab that demonstrates every concept in your task inside one clean, interactive application.</p>
          <div className="hero-actions">
            <Link className="btn primary" to="/hooks">Open Hooks Lab →</Link>
            <Link className="btn secondary" to="/router">Explore Router Lab</Link>
          </div>
        </div>
        <div className="hero-card glass">
          <div className="terminal-top"><i></i><i></i><i></i><span>reactlab.jsx</span></div>
          <pre>{`const skills = [\n  'useRef',\n  'useMemo',\n  'useCallback',\n  'useContext',\n  'Custom Hooks',\n  'React Router'\n]`}</pre>
        </div>
      </section>

      <section className="section">
        <div className="section-heading"><div><div className="eyebrow">WHAT YOU’LL PRACTICE</div><h2>Every task, visibly implemented</h2></div></div>
        <div className="concept-grid">
          {concepts.map(([name, desc], i) => <div className="concept-card glass" key={name}><span>0{i+1}</span><h3>{name}</h3><p>{desc}</p></div>)}
        </div>
      </section>
    </div>
  )
}
