import { Link, useNavigate, useParams } from 'react-router-dom'
import { courses } from '../../data'
export default function CourseDetails() {
  const { courseId } = useParams()
  const navigate = useNavigate()
  const course = courses[courseId]
  if (!course) return <div><h2>Course not found</h2><Link className="btn primary" to="/dashboard/courses">Back to courses</Link></div>
  return <div><div className="eyebrow">DYNAMIC PARAM</div><h2>{course.name}</h2><p className="lead">This page reads <code>courseId</code> from <code>useParams()</code>: <b>{courseId}</b></p><div className="detail-card glass"><span className="badge">{course.level}</span><h3>{course.name}</h3><p>{course.description}</p><div className="metric">Duration: <b>{course.duration}</b></div></div><div className="inline"><button className="btn primary" onClick={() => navigate('/dashboard/courses')}>← All courses</button><button className="btn secondary" onClick={() => navigate('/dashboard')}>Dashboard home</button></div></div>
}
