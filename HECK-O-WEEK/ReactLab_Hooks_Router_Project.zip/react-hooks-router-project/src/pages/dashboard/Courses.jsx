import { Link } from 'react-router-dom'
import { courses } from '../../data'
export default function Courses() {
  return <div><div className="eyebrow">NESTED ROUTE</div><h2>Courses</h2><p className="lead">Each card navigates to a dynamic URL such as <code>/dashboard/courses/react</code>.</p><div className="course-grid">{Object.entries(courses).map(([id, course]) => <Link className="course-card glass" to={id} key={id}><div className="course-icon">{id === 'react' ? '⚛' : id === 'python' ? '🐍' : '🛡️'}</div><div><h3>{course.name}</h3><p>{course.description}</p><span>{course.level} • {course.duration}</span></div><b>→</b></Link>)}</div></div>
}
