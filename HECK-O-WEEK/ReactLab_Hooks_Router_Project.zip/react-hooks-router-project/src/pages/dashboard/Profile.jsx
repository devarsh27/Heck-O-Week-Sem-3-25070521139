import { useLocalStorage } from '../../hooks/useLocalStorage'
export default function Profile() {
  const [name, setName] = useLocalStorage('reactlab-profile-name', 'Devarsh Gupta')
  return <div><div className="eyebrow">NESTED ROUTE</div><h2>Profile</h2><p className="lead">URL: <code>/dashboard/profile</code></p><div className="demo-card glass"><label>Your name</label><input value={name} onChange={e => setName(e.target.value)}/><p className="muted">This also uses the custom <code>useLocalStorage</code> hook.</p></div></div>
}
