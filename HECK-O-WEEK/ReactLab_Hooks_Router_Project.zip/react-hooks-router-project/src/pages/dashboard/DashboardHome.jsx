import { Link } from 'react-router-dom'
export default function DashboardHome() {
  return <div><div className="eyebrow">INDEX ROUTE</div><h2>Welcome back 👋</h2><p className="lead">This component appears at <code>/dashboard</code> because it is the index child of the dashboard route.</p><div className="stat-grid"><div className="stat glass"><small>Courses</small><b>6</b></div><div className="stat glass"><small>Progress</small><b>78%</b></div><div className="stat glass"><small>Streak</small><b>12d</b></div></div><Link className="btn primary" to="courses">View courses →</Link></div>
}
