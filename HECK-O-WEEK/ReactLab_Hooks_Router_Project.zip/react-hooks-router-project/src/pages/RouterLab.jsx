import { Link, useNavigate } from 'react-router-dom'
import { useDocumentTitle } from '../hooks/useDocumentTitle'
import Section from '../components/Section'

export default function RouterLab() {
  useDocumentTitle('Router Lab')
  const navigate = useNavigate()
  return (
    <div>
      <Section eyebrow="ROUTES" title="Move around the application">
        <div className="demo-card glass">
          <div className="route-map"><span>/</span><i>→</i><span>/hooks</span><i>→</i><span>/dashboard</span><i>→</i><span>/dashboard/courses</span></div>
          <p>These URLs are declared using <code>&lt;Routes&gt;</code> and <code>&lt;Route&gt;</code>.</p>
          <div className="inline"><Link className="btn secondary" to="/hooks">Go to Hooks</Link><button className="btn primary" onClick={() => navigate('/dashboard')}>Navigate to Dashboard</button></div>
        </div>
      </Section>

      <Section eyebrow="NESTED ROUTES" title="Dashboard uses child routes">
        <div className="three-col">
          <Link className="route-card glass" to="/dashboard"><b>/dashboard</b><span>Index route</span></Link>
          <Link className="route-card glass" to="/dashboard/profile"><b>/dashboard/profile</b><span>Nested route</span></Link>
          <Link className="route-card glass" to="/dashboard/courses"><b>/dashboard/courses</b><span>Nested route + params below</span></Link>
        </div>
      </Section>

      <Section eyebrow="PARAMS" title="Dynamic URL parameter">
        <div className="demo-card glass"><p>Try a dynamic route where <code>:courseId</code> changes.</p><div className="inline"><Link className="btn primary" to="/dashboard/courses/react">React details</Link><Link className="btn secondary" to="/dashboard/courses/python">Python details</Link><Link className="btn secondary" to="/dashboard/courses/cybersecurity">Cybersecurity details</Link></div></div>
      </Section>
    </div>
  )
}
