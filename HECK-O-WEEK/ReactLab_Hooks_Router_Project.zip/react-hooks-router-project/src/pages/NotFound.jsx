import { Link } from 'react-router-dom'
export default function NotFound() { return <div className="empty"><div className="big-number">404</div><h1>Route not found</h1><p>Try a route from the navbar.</p><Link className="btn primary" to="/">Back home</Link></div> }
