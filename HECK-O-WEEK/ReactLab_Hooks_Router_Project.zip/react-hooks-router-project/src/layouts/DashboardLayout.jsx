import { NavLink, Outlet, useNavigate } from 'react-router-dom'

export default function DashboardLayout() {
  const navigate = useNavigate()
  return (
    <div>
      <div className="dashboard-head"><div><div className="eyebrow">NESTED ROUTE</div><h1>Student Dashboard</h1><p>Parent route: <code>/dashboard</code> • Child content renders inside <code>&lt;Outlet /&gt;</code>.</p></div><button className="btn secondary" onClick={() => navigate('/router')}>← Router Lab</button></div>
      <div className="dashboard-layout">
        <aside className="sidebar glass">
          <NavLink end to="/dashboard">Overview</NavLink>
          <NavLink to="/dashboard/profile">Profile</NavLink>
          <NavLink to="/dashboard/courses">Courses</NavLink>
        </aside>
        <section className="dashboard-content"><Outlet /></section>
      </div>
    </div>
  )
}
