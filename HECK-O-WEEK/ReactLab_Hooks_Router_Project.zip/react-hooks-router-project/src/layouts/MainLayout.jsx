import { Outlet } from 'react-router-dom'
import Navbar from '../components/Navbar'

export default function MainLayout() {
  return (
    <div className="app-shell">
      <Navbar />
      <main className="page-wrap"><Outlet /></main>
      <footer>Built for React Hooks + React Router practice • 2026</footer>
    </div>
  )
}
