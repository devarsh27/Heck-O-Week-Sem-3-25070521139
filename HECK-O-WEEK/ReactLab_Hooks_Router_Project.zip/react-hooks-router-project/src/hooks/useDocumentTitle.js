import { useEffect } from 'react'

export function useDocumentTitle(title) {
  useEffect(() => {
    const previous = document.title
    document.title = `${title} | ReactLab`
    return () => { document.title = previous }
  }, [title])
}
