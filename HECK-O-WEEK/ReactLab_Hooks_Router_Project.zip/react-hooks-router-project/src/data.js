export const courses = {
  react: { name: 'React Mastery', level: 'Intermediate', duration: '6 weeks', description: 'Components, hooks, reusable patterns and routing.' },
  python: { name: 'Python Foundations', level: 'Beginner', duration: '4 weeks', description: 'Syntax, functions, OOP, modules and practical problem solving.' },
  cybersecurity: { name: 'Cybersecurity Basics', level: 'Beginner', duration: '5 weeks', description: 'Networking foundations, security concepts, Linux and safe labs.' },
}
