export default function Section({ eyebrow, title, children, right }) {
  return (
    <section className="section">
      <div className="section-heading">
        <div><div className="eyebrow">{eyebrow}</div><h2>{title}</h2></div>
        {right}
      </div>
      {children}
    </section>
  )
}
