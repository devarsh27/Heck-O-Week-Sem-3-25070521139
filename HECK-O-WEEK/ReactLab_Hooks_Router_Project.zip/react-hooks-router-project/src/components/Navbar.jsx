import { NavLink } from 'react-router-dom'
import ThemeToggle from './ThemeToggle'

const navItems = [
  ['/', 'Home'],
  ['/hooks', 'Hooks Lab'],
  ['/router', 'Router Lab'],
  ['/dashboard', 'Dashboard'],
]

export default function Navbar() {
  return (
    <header className="navbar">
      <NavLink to="/" className="brand">
        <span className="brand-mark">R</span>
        <span>React<span>Lab</span></span>
      </NavLink>
      <nav>
        {navItems.map(([to, label]) => (
          <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
            {label}
          </NavLink>
        ))}
      </nav>
      <ThemeToggle />
    </header>
  )
}
